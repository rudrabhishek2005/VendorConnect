export interface User {
  id: string;
  email: string;
  role: 'vendor' | 'supplier' | 'admin';
  created_at: string;
}

export interface UserProfile {
  id: string;
  user_id: string;
  role: 'vendor' | 'supplier' | 'admin';
  name: string;
  phone: string;
  language: 'en' | 'te' | 'hi' | 'ta';
  location: string;
  pincode: string;
  gps_coordinates?: {
    lat: number;
    lng: number;
  };
  voice_settings: {
    speed: number;
    pitch: number;
    volume: number;
  };
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  supplier_id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  unit: string;
  stock_quantity: number;
  minimum_order: number;
  bulk_discount?: number;
  images?: string[];
  created_at: string;
  updated_at: string;
}

export interface Order {
  id: string;
  vendor_id: string;
  supplier_id: string;
  status: 'pending' | 'confirmed' | 'dispatched' | 'delivered' | 'cancelled';
  total_amount: number;
  delivery_date?: string;
  notes?: string;
  is_bulk_order: boolean;
  bulk_group_id?: string;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  created_at: string;
}

export interface BulkGroup {
  id: string;
  title: string;
  description?: string;
  location: string;
  pincode: string;
  target_quantity: number;
  current_quantity: number;
  price_per_unit: number;
  deadline: string;
  status: 'open' | 'closed' | 'completed';
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'price_alert' | 'order_update' | 'scheme_alert' | 'general';
  is_read: boolean;
  sms_sent: boolean;
  whatsapp_sent: boolean;
  created_at: string;
}

export interface Review {
  id: string;
  vendor_id: string;
  supplier_id: string;
  order_id: string;
  rating: number;
  comment?: string;
  created_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  description: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high';
  assigned_to?: string;
  created_at: string;
  updated_at: string;
}

export interface GovtScheme {
  id: string;
  title: string;
  description: string;
  eligibility_criteria: string[];
  application_process: string[];
  deadline?: string;
  audio_guide_url?: string;
  documents_required: string[];
  benefits: string[];
  contact_info: {
    phone?: string;
    email?: string;
    website?: string;
  };
  language: 'en' | 'te' | 'hi' | 'ta';
  created_at: string;
  updated_at: string;
}

export interface VoiceCommand {
  command: string;
  action: string;
  page?: string;
  parameters?: Record<string, any>;
}