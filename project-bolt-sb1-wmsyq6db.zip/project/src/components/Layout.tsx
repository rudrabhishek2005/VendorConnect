import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../hooks/useAuth';
import { useVoice } from '../hooks/useVoice';
import { VoiceButton } from './VoiceButton';
import { LanguageSelector } from './LanguageSelector';
import { VoiceNavigatedButton } from './VoiceNavigatedButton';
import { 
  Home, 
  ShoppingCart, 
  Package, 
  Users, 
  FileText, 
  GraduationCap, 
  Store, 
  Bell, 
  AlertTriangle, 
  User, 
  BarChart3, 
  Receipt,
  Settings,
  LogOut
} from 'lucide-react';
import { signOut } from '../lib/supabase';

interface LayoutProps {
  children: React.ReactNode;
  currentPage?: string;
}

export const Layout: React.FC<LayoutProps> = ({ children, currentPage = '' }) => {
  const { t, i18n } = useTranslation();
  const { user, profile, isVendor, isSupplier, isAdmin } = useAuth();
  const { speak, processCommand } = useVoice({ 
    language: i18n.language 
  });

  // Voice command handler
  const handleVoiceCommand = (command: string) => {
    const processedCommand = processCommand(command);
    
    if (processedCommand) {
      switch (processedCommand.action) {
        case 'navigate':
          window.location.hash = processedCommand.target;
          break;
        case 'change_language':
          i18n.changeLanguage(processedCommand.target);
          break;
        case 'submit_form':
          const submitBtn = document.querySelector('button[type="submit"]') as HTMLButtonElement;
          if (submitBtn) submitBtn.click();
          break;
        default:
          speak(t('voice.command_not_recognized'));
      }
    }
  };

  // Speak page summary on load
  useEffect(() => {
    if (currentPage) {
      const pageName = t(`nav.${currentPage}`) || currentPage;
      speak(`${t('common.current_page')}: ${pageName}`);
    }
  }, [currentPage, speak, t]);

  const handleLogout = async () => {
    await signOut();
    speak(t('auth.logout_success'));
  };

  if (!user || !profile) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-4">
                <Store className="w-8 h-8 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-900">
                  VendorConnect
                </h1>
              </div>
              <LanguageSelector />
            </div>
          </div>
        </header>
        <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          {children}
        </main>
      </div>
    );
  }

  const navigation = [
    { name: t('nav.dashboard'), href: '#/', icon: Home, roles: ['vendor', 'supplier', 'admin'] },
    { name: t('nav.orders'), href: '#/orders', icon: ShoppingCart, roles: ['vendor', 'supplier'] },
    { name: t('nav.products'), href: '#/products', icon: Package, roles: ['supplier', 'admin'] },
    { name: t('nav.bulk_orders'), href: '#/bulk-orders', icon: Users, roles: ['vendor'] },
    { name: t('nav.schemes'), href: '#/schemes', icon: FileText, roles: ['vendor'] },
    { name: t('nav.training'), href: '#/training', icon: GraduationCap, roles: ['vendor', 'supplier'] },
    { name: t('nav.storefronts'), href: '#/storefronts', icon: Store, roles: ['vendor'] },
    { name: t('nav.notifications'), href: '#/notifications', icon: Bell, roles: ['vendor', 'supplier'] },
    { name: t('nav.disputes'), href: '#/disputes', icon: AlertTriangle, roles: ['vendor', 'supplier'] },
    { name: t('nav.analytics'), href: '#/analytics', icon: BarChart3, roles: ['vendor', 'supplier', 'admin'] },
    { name: t('nav.invoices'), href: '#/invoices', icon: Receipt, roles: ['vendor', 'supplier'] },
  ];

  const filteredNavigation = navigation.filter(item => 
    item.roles.includes(profile.role)
  );

  const roleColor = {
    vendor: 'text-green-600 bg-green-50',
    supplier: 'text-blue-600 bg-blue-50', 
    admin: 'text-purple-600 bg-purple-50'
  }[profile.role];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Store className="w-8 h-8 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-900">
                VendorConnect
              </h1>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${roleColor}`}>
                {t(`auth.${profile.role}`)}
              </span>
            </div>

            <div className="flex items-center space-x-4">
              <VoiceButton onCommand={handleVoiceCommand} />
              <LanguageSelector />
              
              <div className="flex items-center space-x-2">
                <User className="w-5 h-5 text-gray-600" />
                <span className="text-sm font-medium text-gray-700">
                  {profile.name}
                </span>
              </div>

              <VoiceNavigatedButton
                onClick={handleLogout}
                variant="ghost"
                size="sm"
                voiceLabel={t('auth.logout')}
              >
                <LogOut className="w-4 h-4" />
              </VoiceNavigatedButton>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white shadow-sm h-screen sticky top-0 overflow-y-auto">
          <div className="p-4">
            <ul className="space-y-2">
              {filteredNavigation.map((item) => {
                const Icon = item.icon;
                const isActive = window.location.hash === item.href;
                
                return (
                  <li key={item.name}>
                    <a
                      href={item.href}
                      className={`
                        flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors
                        ${isActive 
                          ? 'bg-blue-100 text-blue-700 font-medium' 
                          : 'text-gray-700 hover:bg-gray-100'
                        }
                      `}
                      onMouseEnter={() => speak(item.name)}
                      onClick={() => speak(item.name)}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{item.name}</span>
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>

          {/* Footer */}
          <div className="border-t mt-8 p-4">
            <a
              href="#/profile"
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
              onMouseEnter={() => speak(t('nav.profile'))}
            >
              <User className="w-5 h-5" />
              <span>{t('nav.profile')}</span>
            </a>
            <a
              href="#/settings"
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
              onMouseEnter={() => speak(t('nav.settings'))}
            >
              <Settings className="w-5 h-5" />
              <span>{t('nav.settings')}</span>
            </a>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {children}
        </main>
      </div>
    </div>
  );
};