import React from 'react';
import { Mic, MicOff, Volume2 } from 'lucide-react';
import { useVoice } from '../hooks/useVoice';
import { useTranslation } from 'react-i18next';

interface VoiceButtonProps {
  onCommand?: (command: string) => void;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'primary' | 'secondary' | 'outline';
}

export const VoiceButton: React.FC<VoiceButtonProps> = ({
  onCommand,
  className = '',
  size = 'md',
  variant = 'primary'
}) => {
  const { t, i18n } = useTranslation();
  const { isSupported, isListening, startListening, stopListening, transcript } = useVoice({
    onCommand,
    language: i18n.language
  });

  const sizeClasses = {
    sm: 'w-8 h-8 p-1.5',
    md: 'w-10 h-10 p-2',
    lg: 'w-12 h-12 p-3'
  };

  const variantClasses = {
    primary: 'bg-blue-600 hover:bg-blue-700 text-white',
    secondary: 'bg-gray-600 hover:bg-gray-700 text-white',
    outline: 'border-2 border-blue-600 text-blue-600 hover:bg-blue-50'
  };

  if (!isSupported) {
    return (
      <div className={`${sizeClasses[size]} ${className} flex items-center justify-center bg-gray-300 rounded-full cursor-not-allowed`}>
        <Volume2 className="w-4 h-4 text-gray-500" />
      </div>
    );
  }

  const handleClick = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  return (
    <div className="relative">
      <button
        onClick={handleClick}
        className={`
          ${sizeClasses[size]} 
          ${isListening ? 'bg-red-600 hover:bg-red-700 text-white animate-pulse' : variantClasses[variant]}
          ${className}
          rounded-full transition-all duration-200 flex items-center justify-center
          focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
        `}
        title={isListening ? t('voice.stop_listening') : t('voice.start_listening')}
      >
        {isListening ? (
          <MicOff className="w-4 h-4" />
        ) : (
          <Mic className="w-4 h-4" />
        )}
      </button>
      
      {isListening && (
        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-black text-white px-3 py-1 rounded text-sm whitespace-nowrap z-10">
          {transcript || t('voice.listening')}
        </div>
      )}
    </div>
  );
};