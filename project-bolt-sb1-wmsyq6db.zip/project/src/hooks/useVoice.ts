import { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';

interface UseVoiceProps {
  onCommand?: (command: string) => void;
  language?: string;
}

export const useVoice = ({ onCommand, language = 'en' }: UseVoiceProps = {}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const [synthesis, setSynthesis] = useState<SpeechSynthesis | null>(null);
  const { t } = useTranslation();

  useEffect(() => {
    // Check for speech recognition support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const speechSynthesis = window.speechSynthesis;

    if (SpeechRecognition && speechSynthesis) {
      setIsSupported(true);
      setSynthesis(speechSynthesis);

      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.maxAlternatives = 1;

      // Set language based on current app language
      const speechLang = {
        'en': 'en-US',
        'te': 'te-IN',
        'hi': 'hi-IN',
        'ta': 'ta-IN'
      }[language] || 'en-US';
      
      recognitionInstance.lang = speechLang;

      recognitionInstance.onstart = () => {
        setIsListening(true);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      recognitionInstance.onresult = (event) => {
        let finalTranscript = '';
        let interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          if (result.isFinal) {
            finalTranscript += result[0].transcript;
          } else {
            interimTranscript += result[0].transcript;
          }
        }

        setTranscript(finalTranscript || interimTranscript);

        if (finalTranscript && onCommand) {
          onCommand(finalTranscript.toLowerCase().trim());
        }
      };

      recognitionInstance.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, [language, onCommand]);

  const startListening = useCallback(() => {
    if (recognition && !isListening) {
      setTranscript('');
      recognition.start();
    }
  }, [recognition, isListening]);

  const stopListening = useCallback(() => {
    if (recognition && isListening) {
      recognition.stop();
    }
  }, [recognition, isListening]);

  const speak = useCallback((text: string, options?: {
    rate?: number;
    pitch?: number;
    volume?: number;  
    lang?: string;
  }) => {
    if (synthesis) {
      // Cancel any ongoing speech
      synthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      
      // Set voice settings
      utterance.rate = options?.rate || 1;
      utterance.pitch = options?.pitch || 1;
      utterance.volume = options?.volume || 1;
      
      // Set language
      const speechLang = {
        'en': 'en-US',
        'te': 'te-IN', 
        'hi': 'hi-IN',
        'ta': 'ta-IN'
      }[options?.lang || language] || 'en-US';
      
      utterance.lang = speechLang;

      // Find appropriate voice
      const voices = synthesis.getVoices();
      const voice = voices.find(v => v.lang.startsWith(speechLang.split('-')[0]));
      if (voice) {
        utterance.voice = voice;
      }

      synthesis.speak(utterance);
    }
  }, [synthesis, language]);

  const speakTranslation = useCallback((key: string, options?: any) => {
    const text = t(key);
    speak(text, options);
  }, [t, speak]);

  // Voice command processing
  const processCommand = useCallback((command: string) => {
    const lowerCommand = command.toLowerCase();

    // Navigation commands
    if (lowerCommand.includes('home') || lowerCommand.includes('హోమ్') || lowerCommand.includes('होम') || lowerCommand.includes('வீடு')) {
      return { action: 'navigate', target: '/' };
    }
    
    if (lowerCommand.includes('orders') || lowerCommand.includes('ఆర్డర్లు') || lowerCommand.includes('ऑर्डर') || lowerCommand.includes('ஆர்டர்கள்')) {
      return { action: 'navigate', target: '/orders' };
    }
    
    if (lowerCommand.includes('profile') || lowerCommand.includes('ప్రొఫైల్') || lowerCommand.includes('प्रोफाइल') || lowerCommand.includes('சுயவிவரம்')) {
      return { action: 'navigate', target: '/profile' };
    }

    // Form actions
    if (lowerCommand.includes('submit') || lowerCommand.includes('చేయ్యు') || lowerCommand.includes('सबमिट') || lowerCommand.includes('சமர்ப்பிக்க')) {
      return { action: 'submit_form' };
    }

    // Language switching
    if (lowerCommand.includes('english')) {
      return { action: 'change_language', target: 'en' };
    }
    if (lowerCommand.includes('telugu') || lowerCommand.includes('తెలుగు')) {
      return { action: 'change_language', target: 'te' };
    }
    if (lowerCommand.includes('hindi') || lowerCommand.includes('हिंदी')) {
      return { action: 'change_language', target: 'hi' };
    }
    if (lowerCommand.includes('tamil') || lowerCommand.includes('தமிழ்')) {
      return { action: 'change_language', target: 'ta' };
    }

    return null;
  }, []);

  return {
    isSupported,
    isListening,
    transcript,
    startListening,
    stopListening,
    speak,
    speakTranslation,
    processCommand
  };
};

// Extend Window interface for TypeScript
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}