import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from './hooks/useAuth';
import { Layout } from './components/Layout';
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { Dashboard } from './pages/Dashboard';
import { OrdersPage } from './pages/OrdersPage';
import { ProductsPage } from './pages/ProductsPage';
import { BulkOrdersPage } from './pages/BulkOrdersPage';
import { SchemesPage } from './pages/SchemesPage';
import { TrainingPage } from './pages/TrainingPage';
import { StorefrontsPage } from './pages/StorefrontsPage';
import { NotificationsPage } from './pages/NotificationsPage'; 
import { DisputesPage } from './pages/DisputesPage';
import { ProfilePage } from './pages/ProfilePage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { InvoicesPage } from './pages/InvoicesPage';
import { SettingsPage } from './pages/SettingsPage';
import './i18n';

function App() {
  const { user, profile, loading } = useAuth();
  const { i18n } = useTranslation();
  const [currentPage, setCurrentPage] = React.useState('');

  // Update language from user profile
  useEffect(() => {
    if (profile?.language && profile.language !== i18n.language) {
      i18n.changeLanguage(profile.language);
    }
  }, [profile?.language, i18n]);

  // Simple router
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1) || '/';
      const page = hash.split('/')[1] || 'dashboard';
      setCurrentPage(page);
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const renderPage = () => {
    const hash = window.location.hash.slice(1) || '/';
    
    if (!user || !profile) {
      if (hash.startsWith('/auth')) {
        return <AuthPage />;
      }
      return <LandingPage />;
    }

    // Protected routes
    switch (hash) {
      case '/':
        return <Dashboard />;
      case '/orders':
        return <OrdersPage />;
      case '/products':
        return <ProductsPage />;
      case '/bulk-orders':
        return <BulkOrdersPage />;
      case '/schemes':
        return <SchemesPage />;
      case '/training':
        return <TrainingPage />;
      case '/storefronts':
        return <StorefrontsPage />;
      case '/notifications':
        return <NotificationsPage />;
      case '/disputes':
        return <DisputesPage />;
      case '/profile':
        return <ProfilePage />;
      case '/analytics':
        return <AnalyticsPage />;
      case '/invoices':
        return <InvoicesPage />;
      case '/settings':
        return <SettingsPage />;
      default:
        return <Dashboard />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user || !profile) {
    return renderPage();
  }

  return (
    <Layout currentPage={currentPage}>
      {renderPage()}
    </Layout>
  );
}

export default App;