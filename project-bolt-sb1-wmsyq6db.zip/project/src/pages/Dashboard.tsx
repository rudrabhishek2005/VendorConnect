import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../hooks/useAuth';
import { useVoice } from '../hooks/useVoice';
import { VoiceNavigatedButton } from '../components/VoiceNavigatedButton';
import { 
  ShoppingCart, 
  Package, 
  Users, 
  TrendingUp, 
  Bell, 
  Plus,
  Eye,
  BarChart3,
  Calendar,
  DollarSign,
  AlertCircle,
  CheckCircle,
  Clock
} from 'lucide-react';
import { getOrders, getProducts, getNotifications, getBulkGroups } from '../lib/supabase';

export const Dashboard: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { profile, user, isVendor, isSupplier } = useAuth();
  const { speak } = useVoice({ language: i18n.language });
  
  const [stats, setStats] = useState({
    totalOrders: 0,
    monthlySpend: 0,
    activeProducts: 0,
    pendingOrders: 0,
    notifications: 0,
    bulkOpportunities: 0
  });
  
  const [recentOrders, setRecentOrders] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user && profile) {
      loadDashboardData();
      speak(`${t('dashboard.welcome')}, ${profile.name}`);
    }
  }, [user, profile, speak, t]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Load orders
      const { data: orders } = await getOrders(user!.id, profile!.role);
      setRecentOrders(orders?.slice(0, 5) || []);
      
      // Load notifications
      const { data: userNotifications } = await getNotifications(user!.id);
      setNotifications(userNotifications?.slice(0, 5) || []);
      
      // Load bulk opportunities (for vendors)
      let bulkOpportunitiesCount = 0;
      if (isVendor) {
        const { data: bulkGroups } = await getBulkGroups(profile!.pincode);
        bulkOpportunitiesCount = bulkGroups?.length || 0;
      }
      
      // Load products (for suppliers)
      let activeProductsCount = 0;
      if (isSupplier) {
        const { data: products } = await getProducts({ supplier_id: user!.id });
        activeProductsCount = products?.length || 0;
      }
      
      // Calculate stats
      const totalOrders = orders?.length || 0;
      const pendingOrders = orders?.filter(o => o.status === 'pending').length || 0;
      const monthlySpend = orders?.reduce((sum, order) => sum + order.total_amount, 0) || 0;
      const unreadNotifications = userNotifications?.filter(n => !n.is_read).length || 0;
      
      setStats({
        totalOrders,
        monthlySpend,
        activeProducts: activeProductsCount,
        pendingOrders,
        notifications: unreadNotifications,
        bulkOpportunities: bulkOpportunitiesCount
      });
      
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const quickActions = isVendor ? [
    {
      icon: Plus,
      title: t('dashboard.create_order'),
      description: 'Place new order with suppliers',
      href: '#/orders/new',
      color: 'bg-green-100 text-green-600'
    },
    {
      icon: Eye,
      title: t('dashboard.view_products'),
      description: 'Browse available products',
      href: '#/storefronts',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      icon: Users,
      title: t('dashboard.bulk_opportunities'),
      description: 'Join bulk orders for better prices',
      href: '#/bulk-orders',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      icon: BarChart3,
      title: t('dashboard.ai_suggestions'),
      description: 'Get AI-powered recommendations',
      href: '#/analytics',
      color: 'bg-orange-100 text-orange-600'
    }
  ] : [
    {
      icon: Package,
      title: 'Manage Products',
      description: 'Add and update your product catalog',
      href: '#/products',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      icon: ShoppingCart,
      title: 'View Orders',
      description: 'Manage incoming orders',
      href: '#/orders',
      color: 'bg-green-100 text-green-600'
    },
    {
      icon: TrendingUp,
      title: 'Analytics',
      description: 'View sales performance',
      href: '#/analytics',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      icon: Users,
      title: 'Bulk Orders',
      description: 'Manage group orders',
      href: '#/bulk-orders',
      color: 'bg-orange-100 text-orange-600'
    }
  ];

  const statCards = [
    {
      title: isVendor ? t('orders.title') : 'Total Orders',
      value: stats.totalOrders,
      icon: ShoppingCart,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: isVendor ? 'Monthly Spend' : 'Active Products',
      value: isVendor ? `₹${stats.monthlySpend.toLocaleString()}` : stats.activeProducts,
      icon: isVendor ? DollarSign : Package,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: t('orders.pending'),
      value: stats.pendingOrders,
      icon: Clock,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    {
      title: t('notifications.title'),
      value: stats.notifications,
      icon: Bell,
      color: 'text-red-600',
      bgColor: 'bg-red-50'
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">
          {t('dashboard.welcome')}, {profile?.name}!
        </h1>
        <p className="text-blue-100">
          {isVendor 
            ? 'Manage your orders and find the best deals'
            : 'Manage your products and fulfill orders'
          }
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
              onMouseEnter={() => speak(`${stat.title}: ${stat.value}`)}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">
                    {stat.title}
                  </p>
                  <p className="text-2xl font-bold text-gray-900">
                    {stat.value}
                  </p>
                </div>
                <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          {t('dashboard.quick_actions')}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <VoiceNavigatedButton
                key={index}
                onClick={() => window.location.hash = action.href}
                className="p-4 bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-all text-left h-auto"
                variant="ghost"
                voiceLabel={action.title}
              >
                <div className="flex items-start space-x-3">
                  <div className={`w-10 h-10 ${action.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-medium text-gray-900 text-sm">
                      {action.title}
                    </h3>
                    <p className="text-xs text-gray-500 mt-1">
                      {action.description}
                    </p>
                  </div>
                </div>
              </VoiceNavigatedButton>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              {t('dashboard.recent_orders')}
            </h2>
            <VoiceNavigatedButton
              onClick={() => window.location.hash = '#/orders'}
              variant="ghost"
              size="sm"
              voiceLabel="View all orders"
            >
              View All
            </VoiceNavigatedButton>
          </div>
          
          <div className="space-y-3">
            {recentOrders.length > 0 ? (
              recentOrders.map((order: any, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                  onMouseEnter={() => speak(`Order ${order.id}, Amount ${order.total_amount} rupees, Status ${order.status}`)}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${
                      order.status === 'delivered' ? 'bg-green-100 text-green-600' :
                      order.status === 'pending' ? 'bg-orange-100 text-orange-600' :
                      'bg-blue-100 text-blue-600'
                    }`}>
                      {order.status === 'delivered' ? <CheckCircle className="w-4 h-4" /> :
                       order.status === 'pending' ? <Clock className="w-4 h-4" /> :
                       <ShoppingCart className="w-4 h-4" />}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        Order #{order.id.slice(0, 8)}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(order.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">
                      ₹{order.total_amount.toLocaleString()}
                    </p>
                    <p className="text-xs text-gray-500 capitalize">
                      {order.status}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <ShoppingCart className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>No recent orders</p>
              </div>
            )}
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              {t('dashboard.notifications')}
            </h2>
            <VoiceNavigatedButton
              onClick={() => window.location.hash = '#/notifications'}
              variant="ghost"
              size="sm"
              voiceLabel="View all notifications"
            >
              View All
            </VoiceNavigatedButton>
          </div>
          
          <div className="space-y-3">
            {notifications.length > 0 ? (
              notifications.map((notification: any, index) => (
                <div
                  key={index}
                  className={`flex items-start space-x-3 p-3 rounded-lg transition-colors cursor-pointer ${
                    notification.is_read ? 'bg-gray-50 hover:bg-gray-100' : 'bg-blue-50 hover:bg-blue-100'
                  }`}
                  onMouseEnter={() => speak(notification.title)}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    notification.type === 'price_alert' ? 'bg-green-100 text-green-600' :
                    notification.type === 'order_update' ? 'bg-blue-100 text-blue-600' :
                    notification.type === 'scheme_alert' ? 'bg-purple-100 text-purple-600' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {notification.type === 'price_alert' ? <TrendingUp className="w-4 h-4" /> :
                     notification.type === 'order_update' ? <ShoppingCart className="w-4 h-4" /> :
                     notification.type === 'scheme_alert' ? <AlertCircle className="w-4 h-4" /> :
                     <Bell className="w-4 h-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">
                      {notification.title}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {notification.message}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      {new Date(notification.created_at).toLocaleString()}
                    </p>
                  </div>
                  {!notification.is_read && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0 mt-2"></div>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Bell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>No new notifications</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};