import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useVoice } from '../hooks/useVoice';
import { VoiceButton } from '../components/VoiceButton';
import { VoiceNavigatedButton } from '../components/VoiceNavigatedButton';
import { LanguageSelector } from '../components/LanguageSelector';
import { Store, User, Building, Shield, MapPin } from 'lucide-react';
import { signUp, signIn, createUserProfile } from '../lib/supabase';

export const AuthPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { speak } = useVoice({ language: i18n.language });
  
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedRole, setSelectedRole] = useState<'vendor' | 'supplier'>('vendor');
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
    phone: '',
    location: '',
    pincode: ''
  });

  useEffect(() => {
    // Check URL params for role
    const urlParams = new URLSearchParams(window.location.search);
    const roleParam = urlParams.get('role');
    if (roleParam === 'vendor' || roleParam === 'supplier') {
      setSelectedRole(roleParam);
    }
    
    speak(isLogin ? t('auth.login') : t('auth.register'));
  }, [isLogin, speak, t]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (isLogin) {
        const { data, error } = await signIn(formData.email, formData.password);
        if (error) throw error;
        speak(t('auth.login_success'));
        window.location.hash = '#/';
      } else {
        // Validation
        if (formData.password !== formData.confirmPassword) {
          throw new Error('Passwords do not match');
        }

        const { data, error } = await signUp(formData.email, formData.password, {
          name: formData.name,
          role: selectedRole
        });
        
        if (error) throw error;

        // Create user profile
        if (data.user) {
          await createUserProfile({
            user_id: data.user.id,
            role: selectedRole,
            name: formData.name,
            phone: formData.phone,
            language: i18n.language,
            location: formData.location,
            pincode: formData.pincode,
            voice_settings: {
              speed: 1,
              pitch: 1,
              volume: 1
            }
          });
        }

        speak(t('auth.register_success'));
        window.location.hash = '#/';
      }
    } catch (err: any) {
      setError(err.message);
      speak(t('common.error') + ': ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const roleOptions = [
    {
      value: 'vendor',
      icon: User,
      title: t('auth.vendor'),
      description: t('auth.role_vendor_desc'),
      color: 'text-green-600 border-green-200 hover:border-green-300'
    },
    {
      value: 'supplier',
      icon: Building,
      title: t('auth.supplier'),
      description: t('auth.role_supplier_desc'),
      color: 'text-blue-600 border-blue-200 hover:border-blue-300'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Store className="w-12 h-12 text-blue-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            VendorConnect
          </h1>
          <p className="text-gray-600">
            {isLogin ? t('auth.login') : t('auth.register')}
          </p>
          
          <div className="flex justify-center mt-4">
            <LanguageSelector />
          </div>
        </div>

        {/* Role Selection (only for registration) */}
        {!isLogin && (
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              {t('auth.role')}
            </label>
            <div className="grid grid-cols-1 gap-3">
              {roleOptions.map((role) => {
                const Icon = role.icon;
                return (
                  <button
                    key={role.value}
                    type="button"
                    onClick={() => {
                      setSelectedRole(role.value as 'vendor' | 'supplier');
                      speak(role.title);
                    }}
                    className={`
                      p-4 border-2 rounded-lg text-left transition-all
                      ${selectedRole === role.value 
                        ? `${role.color} bg-opacity-10` 
                        : 'border-gray-200 hover:border-gray-300'
                      }
                    `}
                    onMouseEnter={() => speak(role.title)}
                  >
                    <div className="flex items-start space-x-3">
                      <Icon className={`w-6 h-6 mt-1 ${selectedRole === role.value ? role.color.split(' ')[0] : 'text-gray-400'}`} />
                      <div>
                        <div className="font-medium text-gray-900">
                          {role.title}
                        </div>
                        <div className="text-sm text-gray-500 mt-1">
                          {role.description}
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl p-8 border border-gray-200">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('auth.email')}
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                onFocus={() => speak(t('auth.email'))}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('auth.password')}
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                onFocus={() => speak(t('auth.password'))}
              />
            </div>

            {!isLogin && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('auth.confirm_password')}
                  </label>
                  <input
                    type="password"
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    onFocus={() => speak(t('auth.confirm_password'))}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('auth.name')}
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    onFocus={() => speak(t('auth.name'))}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('auth.phone')}
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    onFocus={() => speak(t('auth.phone'))}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {t('auth.location')}
                    </label>
                    <input
                      type="text"
                      name="location"
                      value={formData.location}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      onFocus={() => speak(t('auth.location'))}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {t('auth.pincode')}
                    </label>
                    <input
                      type="text"
                      name="pincode"
                      value={formData.pincode}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      onFocus={() => speak(t('auth.pincode'))}
                    />
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="mt-6">
            <VoiceNavigatedButton
              type="submit"
              disabled={loading}
              className="w-full"
              size="lg"
              voiceLabel={isLogin ? t('auth.login') : t('auth.register')}
            >
              {loading ? t('common.loading') : (isLogin ? t('auth.login') : t('auth.register'))}
            </VoiceNavigatedButton>
          </div>

          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => {
                setIsLogin(!isLogin);
                setError('');
                speak(isLogin ? t('auth.register') : t('auth.login'));
              }}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              {isLogin ? t('auth.signup_prompt') : t('auth.signin_prompt')}
            </button>
          </div>

          {isLogin && (
            <div className="mt-2 text-center">
              <button
                type="button"
                className="text-gray-500 hover:text-gray-700 text-sm"
                onClick={() => speak(t('auth.forgot_password'))}
              >
                {t('auth.forgot_password')}
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};