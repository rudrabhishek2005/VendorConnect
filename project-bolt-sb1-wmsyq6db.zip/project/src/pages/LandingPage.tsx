import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useVoice } from '../hooks/useVoice';
import { LanguageSelector } from '../components/LanguageSelector';
import { VoiceButton } from '../components/VoiceButton';
import { VoiceNavigatedButton } from '../components/VoiceNavigatedButton';
import { 
  Store, 
  Mic, 
  Globe, 
  Users, 
  TrendingUp, 
  Shield, 
  Smartphone,
  Star,
  CheckCircle
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { speak, processCommand } = useVoice({ language: i18n.language });

  useEffect(() => {
    speak(t('landing.welcome_message'));
  }, [speak, t]);

  const handleVoiceCommand = (command: string) => {
    const processedCommand = processCommand(command);
    
    if (processedCommand) {
      switch (processedCommand.action) {
        case 'navigate':
          if (processedCommand.target === '/auth') {
            window.location.hash = '#/auth';
          }
          break;
        case 'change_language':
          i18n.changeLanguage(processedCommand.target);
          break;
      }
    }
  };

  const features = [
    {
      icon: Mic,
      title: t('landing.features.voice_commands.title'),
      description: t('landing.features.voice_commands.description')
    },
    {
      icon: Globe,
      title: t('landing.features.multilingual.title'),
      description: t('landing.features.multilingual.description')
    },
    {
      icon: Users,
      title: t('landing.features.bulk_orders.title'),
      description: t('landing.features.bulk_orders.description')
    },
    {
      icon: TrendingUp,
      title: t('landing.features.ai_insights.title'),
      description: t('landing.features.ai_insights.description')
    },
    {
      icon: Shield,
      title: t('landing.features.secure.title'),
      description: t('landing.features.secure.description')
    },
    {
      icon: Smartphone,
      title: t('landing.features.mobile_first.title'),
      description: t('landing.features.mobile_first.description')
    }
  ];

  const testimonials = [
    {
      name: "राजेश कुमार",
      role: "Street Vendor, Delhi",
      content: "इस ऐप से मेरा काम बहुत आसान हो गया है। आवाज से ऑर्डर कर सकता हूं।",
      rating: 5
    },
    {
      name: "వెంకట రావు",
      role: "Supplier, Hyderabad", 
      content: "వాయిస్ కమాండ్స్ చాలా బాగున్నాయి. ఎక్కువ ఆర్డర్లు వస్తున్నాయి.",
      rating: 5
    },
    {
      name: "முருகன்",
      role: "Vendor, Chennai",
      content: "குரல் மூலம் ஆர்டர் செய்வது மிகவும் எளிது. நேரம் மிச்சமாகிறது.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Store className="w-8 h-8 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-900">
                VendorConnect
              </h1>
            </div>

            <div className="flex items-center space-x-4">
              <VoiceButton onCommand={handleVoiceCommand} />
              <LanguageSelector />
              <VoiceNavigatedButton
                onClick={() => window.location.hash = '#/auth'}
                variant="outline"
                voiceLabel={t('auth.login')}
              >
                {t('auth.login')}
              </VoiceNavigatedButton>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 mb-6">
            <span className="text-blue-600">{t('landing.hero.title_part1')}</span>
            <br />
            {t('landing.hero.title_part2')}
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            {t('landing.hero.subtitle')}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <VoiceNavigatedButton
              onClick={() => window.location.hash = '#/auth?role=vendor'}
              size="lg"
              className="w-full sm:w-auto"
              voiceLabel={t('landing.cta.vendor')}
            >
              <Users className="w-5 h-5 mr-2" />
              {t('landing.cta.vendor')}
            </VoiceNavigatedButton>
            
            <VoiceNavigatedButton
              onClick={() => window.location.hash = '#/auth?role=supplier'}
              variant="outline"
              size="lg"
              className="w-full sm:w-auto"
              voiceLabel={t('landing.cta.supplier')}
            >
              <Store className="w-5 h-5 mr-2" />
              {t('landing.cta.supplier')}
            </VoiceNavigatedButton>
          </div>

          {/* Voice Demo */}
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 max-w-md mx-auto border border-gray-200">
            <div className="flex items-center justify-center mb-4">
              <Mic className="w-8 h-8 text-blue-600" />
            </div>
            <p className="text-sm text-gray-600 mb-4">
              {t('landing.voice_demo.title')}
            </p>
            <div className="space-y-2 text-sm">
              <div className="bg-blue-50 rounded-lg p-2">
                "{t('landing.voice_demo.example1')}"
              </div>
              <div className="bg-green-50 rounded-lg p-2">
                "{t('landing.voice_demo.example2')}"
              </div>
              <div className="bg-purple-50 rounded-lg p-2">
                "{t('landing.voice_demo.example3')}"
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              {t('landing.features.title')}
            </h2>
            <p className="text-xl text-gray-600">
              {t('landing.features.subtitle')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
                  onMouseEnter={() => speak(feature.title)}
                >
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              {t('landing.testimonials.title')}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                onMouseEnter={() => speak(testimonial.content)}
              >
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic">
                  "{testimonial.content}"
                </p>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            {t('landing.final_cta.title')}
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            {t('landing.final_cta.subtitle')}
          </p>
          
          <VoiceNavigatedButton
            onClick={() => window.location.hash = '#/auth'}
            variant="outline"
            size="lg"
            className="bg-white text-blue-600 hover:bg-gray-50 border-white"
            voiceLabel={t('landing.final_cta.button')}
          >
            {t('landing.final_cta.button')}
          </VoiceNavigatedButton>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Store className="w-6 h-6" />
                <span className="text-lg font-bold">VendorConnect</span>
              </div>
              <p className="text-gray-400">
                {t('landing.footer.description')}
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">{t('landing.footer.features')}</h3>
              <ul className="space-y-2 text-gray-400">
                <li>{t('landing.footer.voice_commands')}</li>
                <li>{t('landing.footer.bulk_orders')}</li>
                <li>{t('landing.footer.multilingual')}</li>
                <li>{t('landing.footer.ai_assistance')}</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">{t('landing.footer.support')}</h3>
              <ul className="space-y-2 text-gray-400">
                <li>{t('landing.footer.help_center')}</li>
                <li>{t('landing.footer.training')}</li>
                <li>{t('landing.footer.contact')}</li>
                <li>{t('landing.footer.community')}</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">{t('landing.footer.languages')}</h3>
              <div className="space-y-2">
                <div className="text-sm text-gray-400">English</div>
                <div className="text-sm text-gray-400">తెలుగు</div>
                <div className="text-sm text-gray-400">हिंदी</div>
                <div className="text-sm text-gray-400">தமிழ்</div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2025 VendorConnect. {t('landing.footer.rights_reserved')}</p>
          </div>
        </div>
      </footer>
    </div>
  );
};