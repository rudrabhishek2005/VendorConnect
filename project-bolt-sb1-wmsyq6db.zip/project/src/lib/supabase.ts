import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Auth helpers
export const signUp = async (email: string, password: string, userData: any) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: userData
    }
  });
  return { data, error };
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });
  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getCurrentUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser();
  return { user, error };
};

// Database helpers
export const createUserProfile = async (profileData: any) => {
  const { data, error } = await supabase
    .from('user_profiles')
    .insert([profileData])
    .select()
    .single();
  return { data, error };
};

export const getUserProfile = async (userId: string) => {
  const { data, error } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('user_id', userId)
    .single();
  return { data, error };
};

export const updateUserProfile = async (userId: string, updates: any) => {
  const { data, error } = await supabase
    .from('user_profiles')
    .update(updates)
    .eq('user_id', userId)
    .select()
    .single();
  return { data, error };
};

// Products
export const getProducts = async (filters?: any) => {
  let query = supabase.from('products').select('*');
  
  if (filters?.category) {
    query = query.eq('category', filters.category);
  }
  if (filters?.supplier_id) {
    query = query.eq('supplier_id', filters.supplier_id);
  }
  
  const { data, error } = await query;
  return { data, error };
};

export const createProduct = async (productData: any) => {
  const { data, error } = await supabase
    .from('products')
    .insert([productData])
    .select()
    .single();
  return { data, error };
};

// Orders
export const createOrder = async (orderData: any) => {
  const { data, error } = await supabase
    .from('orders')
    .insert([orderData])
    .select()
    .single();
  return { data, error };
};

export const getOrders = async (userId: string, role: string) => {
  const column = role === 'vendor' ? 'vendor_id' : 'supplier_id';
  const { data, error } = await supabase
    .from('orders')
    .select(`
      *,
      order_items (
        *,
        products (*)
      )
    `)
    .eq(column, userId)
    .order('created_at', { ascending: false });
  return { data, error };
};

// Bulk Groups
export const getBulkGroups = async (pincode?: string) => {
  let query = supabase
    .from('bulk_groups')
    .select('*')
    .eq('status', 'open');
    
  if (pincode) {
    query = query.eq('pincode', pincode);
  }
  
  const { data, error } = await query.order('created_at', { ascending: false });
  return { data, error };
};

export const joinBulkGroup = async (groupId: string, userId: string, quantity: number) => {
  // This would involve creating an order and updating the bulk group
  const { data, error } = await supabase.rpc('join_bulk_group', {
    group_id: groupId,
    user_id: userId,
    quantity: quantity
  });
  return { data, error };
};

// Notifications
export const createNotification = async (notificationData: any) => {
  const { data, error } = await supabase
    .from('notifications')
    .insert([notificationData])
    .select()
    .single();
  return { data, error };
};

export const getNotifications = async (userId: string) => {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  return { data, error };
};

export const markNotificationAsRead = async (notificationId: string) => {
  const { data, error } = await supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('id', notificationId);
  return { data, error };
};

// Government Schemes
export const getGovtSchemes = async (language: string) => {
  const { data, error } = await supabase
    .from('govt_schemes')
    .select('*')
    .eq('language', language)
    .order('created_at', { ascending: false });
  return { data, error };
};

// Support Tickets
export const createSupportTicket = async (ticketData: any) => {
  const { data, error } = await supabase
    .from('support_tickets')
    .insert([ticketData])
    .select()
    .single();
  return { data, error };
};

export const getSupportTickets = async (userId: string) => {
  const { data, error } = await supabase
    .from('support_tickets')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  return { data, error };
};